# Tesla Instrument Cluster (remodeled in Qt)
This is a personal project, I worked on in June 2015, to get familiar with Qt.

[Youtube-Link](https://www.youtube.com/watch?v=h8Iwe4iJXOc)
